<h1 style="width: 100%; text-align: center;">LỖI LIÊN QUAN ĐẾN CƠ SỞ DỮ LIỆU</h1>
<hr>
<p style="width: 100%; text-align: center; ">Lỗi: <?php echo $exception->getMessage() ?></p>
<p style="width: 100%; text-align: center; ">File: <?php echo $exception->getFile() ?></p>
<p style="width: 100%; text-align: center; ">Line: <?php echo $exception->getLine() ?></p>